const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "change-this-password";
const SESSION_SECRET = process.env.SESSION_SECRET || "change-this-session-secret";
const DATA_DIR = path.join(__dirname, "data");
const APK_DIR = path.join(__dirname, "uploads");
const DB_FILE = path.join(DATA_DIR, "apps.json");

for (const dir of [DATA_DIR, APK_DIR]) fs.mkdirSync(dir, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, "[]");

const readApps = () => JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
const writeApps = apps => fs.writeFileSync(DB_FILE, JSON.stringify(apps, null, 2));

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.urlencoded({ extended: true }));
app.use(express.json({ limit: "1mb" }));
app.use(session({
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 8 *  60 *  60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, APK_DIR),
  filename: (_, file, cb) => cb(null, crypto.randomUUID() + ".apk")
});
const upload = multer({
  storage,
  limits: { fileSize: 200 * 1024 * 1024 },
  fileFilter: (_, file, cb) => {
    if (path.extname(file.originalname).toLowerCase() !== ".apk") return cb(new Error("فقط فایل APK مجاز است."));
    cb(null, true);
  }
});
const requireAdmin = (req, res, next) => req.session.admin ? next() : res.status(401).json({ error: "ابتدا وارد پنل مدیریت شوید." });

app.get("/api/apps", (_, res) => {
  res.json(readApps().map(({ file, ...app }) => app).sort((a,b) => b.createdAt - a.createdAt));
});
app.post("/api/admin/login", (req, res) => {
  const { username, password } = req.body;
  if (username === ADMIN_USER && password === ADMIN_PASSWORD) {
    req.session.admin = true;
    return res.json({ ok: true });
  }
  res.status(401).json({ error: "نام کاربری یا رمز عبور اشتباه است." });
});
app.post("/api/admin/logout", requireAdmin, (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});
app.get("/api/admin/session", (req, res) => res.json({ authenticated: !!req.session.admin }));
app.post("/api/admin/apps", requireAdmin, upload.single("apk"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "فایل APK انتخاب نشده است." });
  const { name, version, category, description } = req.body;
  if (!name || !version) {
    fs.unlinkSync(req.file.path);
    return res.status(400).json({ error: "نام برنامه و نسخه الزامی است." });
  }
  const apps = readApps();
  const item = {
    id: crypto.randomUUID(),
    name: String(name).slice(0, 80),
    version: String(version).slice(0, 30),
    category: String(category || "عمومی").slice(0, 40),
    description: String(description || "").slice(0, 2000),
    file: req.file.filename,
    size: req.file.size,
    downloads: 0,
    createdAt: Date.now()
  };
  apps.push(item);
  writeApps(apps);
  const { file, ...publicItem } = item;
  res.status(201).json(publicItem);
});
app.delete("/api/admin/apps/:id", requireAdmin, (req, res) => {
  const apps = readApps();
  const item = apps.find(a => a.id === req.params.id);
  if (!item) return res.status(404).json({ error: "برنامه پیدا نشد." });
  const filePath = path.join(APK_DIR, item.file);
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  writeApps(apps.filter(a => a.id !== item.id));
  res.json({ ok: true });
});
app.get("/download/:id", (req, res) => {
  const apps = readApps();
  const item = apps.find(a => a.id === req.params.id);
  if (!item) return res.status(404).send("فایل پیدا نشد.");
  const filePath = path.join(APK_DIR, item.file);
  if (!fs.existsSync(filePath)) return res.status(404).send("فایل در دسترس نیست.");
  item.downloads += 1;
  writeApps(apps);
  res.download(filePath, `${item.name.replace(/[^\w\u0600-\u06FF-]/g, "_")}.apk`);
});

app.use((err, req, res, next) => {
  console.error(err.message);
  res.status(400).json({ error: err.message || "خطای نامشخص" });
});
app.listen(PORT, () => console.log(`Androidium is running on http://localhost:${PORT}`));
